plugins = Sketchup.find_support_file("Plugins")
sfile = File.join(plugins, "hammertime", "boomer_dive_01.wav")
icon = File.join(plugins, "hammertime", "source_ico.png")
tb = UI::Toolbar.new("Hammertime")
cmd = UI::Command.new("spititout") { reht }
#cmd = UI::Command.new("Doh") { UI.play_sound(sfile);Sketchup.undo }
cmd.small_icon = icon
cmd.large_icon = icon
cmd.tooltip = cmd.status_bar_text = "Hammertime!"
tb.add_item(cmd)
tb.show


def reht
#UI.play_sound(sfile) 
load "ht.rb"
puts( "Reloading Hammertime...")
ht
end
