The files and folders here are examples.  When you create your real files, they should be placed in your "\steamapps\common\Counter-Strike Global Offensive\csgo\maps\cfg" folder if they are to function.

See https://developer.valvesoftware.com/wiki/CSGO_Custom_Game_Mode for more info.