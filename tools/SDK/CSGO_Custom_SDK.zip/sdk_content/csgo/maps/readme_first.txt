The files and folders here are examples.  When you create your real files, they should be placed in your "\steamapps\common\Counter-Strike Global Offensive\csgo\maps" folder if they are to function.

<mapname>.txt 
The text files can be used to put text in the loading screen side bar.  Explain the rules of the map or tell a story.  It's up to you.

<mapname>.kv
The kv files are used to define what models are used on the map.  Only 5 unique models are loaded per team.

 