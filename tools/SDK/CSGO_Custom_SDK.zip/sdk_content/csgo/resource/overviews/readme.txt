To learn how to do overviews, see this wiki page.
https://developer.valvesoftware.com/wiki/Overview