The files and folders here are examples.  When you create your real files, they should be placed in your "\steamapps\common\Counter-Strike Global Offensive\csgo" folder if they are to function.
 